import numpy as np
import os
import tqdm
import pickle

def build_state(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        all_text = f.read().split('\n')

    res = []
    all_text_ = []
    for text in all_text:
        per_res = []
        if len(text) > 0:
            text_ = text.strip('“').strip().split(' ')
            for word in text_:
                if len(word) == 1:
                    per_res.append('S')
                elif len(word) == 2:
                    per_res.append('BE')
                elif len(word) > 2:
                    per_res.append('B' + 'M' * (len(word) - 2) + 'E')
                else:  # word为空
                    pass
            res.append(' '.join(per_res))
            all_text_.append(' '.join(text_))

    with open('train_text_state.txt', 'w', encoding='utf-8') as f:
        f.write('\n'.join(res))

    with open('corpus.txt', 'w', encoding='utf-8') as f:
        f.write('\n'.join(all_text_))

class HMM:
    def __init__(self):
        self.state2index = {'B': 0, 'M': 1, 'E': 2, 'S': 3}
        self.index2state = ['B', 'M', 'E', 'S']
        self.init_matrix = np.zeros(len(self.state2index))
        self.transfer_matrix = np.zeros(shape=(4, 4))
        self.emit_matrix = [{}, {}, {}, {}]


    def count_matrix(self, all_text, all_state):
        for per_text, per_state in zip(all_text, all_state):
            per_text = [chair for chair in per_text if chair != ' ']
            per_state = [chair for chair in per_state if chair != ' ']
            per_state_index = [self.state2index[state] for state in per_state]
            for i in range(len(per_text)):
                if i == 0:
                    self.init_matrix[per_state_index[i]] += 1

                self.emit_matrix[per_state_index[i]][per_text[i]] = self.emit_matrix[per_state_index[i]].get(per_text[i], 0) + 1

            for i, j in zip(per_state_index[:-1], per_state_index[1:]):
                self.transfer_matrix[i][j] += 1

    def normalize_matrix(self):
        self.init_pro = self.init_matrix / np.sum(self.init_matrix)
        self.transfer_pro = self.transfer_matrix / np.sum(self.transfer_matrix, axis=1, keepdims=True)
        self.emit_pro = [{}, {}, {}, {}]
        emit_pro_sum = [0, 0, 0, 0]
        for i in range(len(emit_pro_sum)):
            for count in self.emit_matrix[i].values():
                emit_pro_sum[i] += count

            for word, count in self.emit_matrix[i].items():
                self.emit_pro[i][word] = count / emit_pro_sum[i]


def viterbi(text, hmm):
    path = [[0], [1], [2], [3]]
    pro = np.array([1.0 for _ in range(len(hmm.index2state))])
    word = text[0]
    exist = word in hmm.emit_pro[0] or\
            word in hmm.emit_pro[1] or\
            word in hmm.emit_pro[2] or\
            word in hmm.emit_pro[3]

    if exist:
        for i in range(len(hmm.index2state)):
            pro[i] *= hmm.init_pro[i] * hmm.emit_pro[i].get(word, 0) * 1000
    else:
        pro = hmm.init_pro * 1000

    for word in text[1:]:
        exist = word in hmm.emit_pro[0] or \
                word in hmm.emit_pro[1] or \
                word in hmm.emit_pro[2] or \
                word in hmm.emit_pro[3]

        if exist:
            new_path = []
            new_pro = []
            for i in range(len(hmm.index2state)):

                max_pro = 0
                for j in range(len(hmm.index2state)):
                    tmp_per_pro = pro[j] * hmm.transfer_pro[j][i] * hmm.emit_pro[i].get(word, 0) * 1000
                    if tmp_per_pro >= max_pro:
                        pre_path = j
                        max_pro = tmp_per_pro
                new_pro.append(max_pro)
                for per_path in path:
                    if per_path[-1] == pre_path:
                        new_path_tmp = per_path[:]  # 这里直接赋值就变成浅拷贝了
                        new_path_tmp.append(i)
                        new_path.append(new_path_tmp)

            path = new_path
            pro = new_pro

        else:
            new_path = []
            new_pro = []
            for i in range(len(hmm.index2state)):

                max_pro = 0
                for j in range(len(hmm.index2state)):
                    tmp_per_pro = pro[j] * hmm.transfer_pro[j][i] * 1000
                    if tmp_per_pro >= max_pro:
                        pre_path = j
                        max_pro = tmp_per_pro
                new_pro.append(max_pro)
                for per_path in path:
                    if per_path[-1] == pre_path:
                        new_path_tmp = per_path[:]
                        new_path_tmp.append(i)
                        new_path.append(new_path_tmp)

            path = new_path
            pro = new_pro
    max_pro = 0
    for i in range(len(hmm.index2state)):
        if pro[i] >= max_pro:
            tmp_path = i
            max_pro = pro[i]

    for i, per_path in enumerate(path):
        if per_path[-1] == tmp_path:
            opt_path = path[i]

    res = ''
    for i in range(len(text)):
        if opt_path[i] == 0 or opt_path[i] == 1:
            res += text[i]
        else:
            res += text[i] + ' '

    return res.strip()


if __name__ == '__main__':
    if not os.path.exists('train_text_state.txt') and not os.path.exists('corpus.txt'):
        path = 'all_train_text.txt'
        build_state(path)

    with open('train_text_state.txt', 'r', encoding='utf-8-sig') as f:
        all_state = f.read().split('\n')

    with open('corpus.txt', 'r', encoding='utf-8-sig') as f:
        all_text = f.read().split('\n')


    if not os.path.exists('hmm.pkl'):
        hmm = HMM()
        hmm.count_matrix(all_text, all_state)
        hmm.normalize_matrix()
        with open('hmm.pkl', 'wb') as f:
            pickle.dump(hmm, f)

    with open('hmm.pkl', 'rb') as f:
        hmm = pickle.load(f)

    while True:
        text = input('请输入文本： ')
        text_cut = viterbi(text, hmm)
        print(text_cut)

