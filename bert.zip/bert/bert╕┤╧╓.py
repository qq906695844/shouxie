import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import os
import random
import math
from tqdm import tqdm


def get_data(path):
    all_data = pd.read_csv(path)
    text1 = all_data['text1'].to_list()
    text2 = all_data['text2'].to_list()
    label = all_data['label'].to_list()

    return text1, text2, label

def get_index2word(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        index2word = f.read().split('\n')
    return index2word




class BDataset(Dataset):
    def __init__(self, all_text1, all_text2, all_label, config):
        self.all_text1 = all_text1
        self.all_text2 = all_text2
        self.all_label = all_label
        self.config = config

    def __len__(self):
        return len(self.all_label)

    def __getitem__(self, index):
        text1 = self.all_text1[index]
        text2 = self.all_text2[index]
        label = self.all_label[index]
        text1_idx = [self.config['word2index'].get(word, self.config['word2index']['[UNK]']) for word in text1]
        text2_idx = [self.config['word2index'].get(word, self.config['word2index']['[UNK]']) for word in text2]

        text_idx = [self.config['word2index']['[CLS]']] + text1_idx + [self.config['word2index']['[SEP]']] + text2_idx + [self.config['word2index']['[SEP]']]
        seg_idx = [0] * (len(text1_idx) + 2) + [1] * (len(text2_idx) + 1)
        mask_idx = [0] * len(text_idx)

        for i, value in enumerate(text_idx):
            if value in [self.config['word2index']['[CLS]'], self.config['word2index']['[SEP]']]:
                continue

            if random.random() < 0.15:
                rate = random.random()
                if rate < 0.8:
                    text_idx[i] = self.config['word2index']['[MASK]']
                    mask_idx[i] = value
                elif rate > 0.9:
                    replace_idx = random.randint(5, len(self.config['word2index'])-1)
                    text_idx[i] = replace_idx
                    mask_idx[i] = value

        # return torch.tensor(text_idx), torch.tensor(label), torch.tensor(seg_idx), torch.tensor(mask_idx)
        return text_idx, label, seg_idx, mask_idx

    def process_batch(self, datas):
        batch_text_idx = []
        batch_label = []
        batch_seg_idx = []
        batch_mask_idx = []
        batch_max_len = max([len(data[0]) for data in datas])
        for data in datas:
            text_idx, label, seg_idx, mask_idx = data
            if len(text_idx) < batch_max_len:
                text_idx += [self.config['word2index']['[PAD]']] * (batch_max_len - len(text_idx))
                seg_idx += [2] * (batch_max_len - len(seg_idx))
                mask_idx += [0] * (batch_max_len - len(mask_idx))
            batch_text_idx.append(text_idx[:self.config['max_lens']])
            batch_seg_idx.append(seg_idx[:self.config['max_lens']])
            batch_mask_idx.append(mask_idx[:self.config['max_lens']])
            batch_label.append(label)

        return torch.tensor(batch_text_idx), torch.tensor(batch_label), torch.tensor(batch_seg_idx), torch.tensor(batch_mask_idx)


class Bert_model(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.bert_embedding = Bert_embedding(config)
        self.encoder_block = [Encoder_block(config).to(config['device']) for _ in range(config['block_nums'])]
        self.pool = Bert_Pool(config['embedding_nums'])

    def forward(self, batch_text_idx, batch_seg_idx):
        out1 = self.bert_embedding(batch_text_idx, batch_seg_idx)
        for encoder_block in self.encoder_block:
            # encoder_block = encoder_block.to(self.config['device'])
            out1 = encoder_block(out1, batch_seg_idx)

        out2 = self.pool(out1)

        return out1, out2

class Bert_embedding(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.word_embedding = nn.Embedding(len(config['index2word']), config['embedding_nums'])
        self.word_embedding.weight.requires_grad = True
        self.seg_embedding = nn.Embedding(config['text_type'], config['embedding_nums'])
        self.seg_embedding.weight.requires_grad = True
        self.postition_embedding = nn.Embedding(config['max_lens'], config['embedding_nums'])
        self.postition_embedding.weight.requires_grad = True

        self.layer_norm = nn.LayerNorm(config['embedding_nums'])
        self.dropout = nn.Dropout(0.1)

    def forward(self, batch_text_idx, batch_seg_idx):
        text_emb = self.word_embedding(batch_text_idx)
        seg_emb = self.seg_embedding(batch_seg_idx)
        pos_idx = torch.tensor([[i for i in range(batch_text_idx.shape[1])] for _ in range(batch_text_idx.shape[0])]).to(batch_text_idx.device)
        pos_emb = self.postition_embedding(pos_idx)

        emb = text_emb + seg_emb + pos_emb
        emb = self.layer_norm(emb)
        emb = self.dropout(emb)

        return emb

class Model(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.bert = Bert_model(config)
        self.mask_classifier = nn.Linear(config['embedding_nums'], len(config['index2word']))
        self.next_classifier = nn.Linear(config['embedding_nums'], 2)
        self.mask_loss_func = nn.CrossEntropyLoss(ignore_index=0)
        self.next_loss_func = nn.CrossEntropyLoss()

    def forward(self, batch_text_idx, batch_seg_idx, batch_label=None, batch_mask_idx=None):
        out1, out2 = self.bert(batch_text_idx, batch_seg_idx)
        pre_mask = self.mask_classifier(out1)
        pre_next = self.next_classifier(out2)

        if batch_label is not None and batch_mask_idx is not None:
            loss1 = self.mask_loss_func(pre_mask.reshape(-1, pre_mask.shape[2]), batch_mask_idx.reshape(-1))
            loss2 = self.next_loss_func(pre_next, batch_label)
            return loss1 + loss2

        else:
            return torch.argmax(pre_mask,dim=-1),  torch.argmax(pre_next,dim=-1)





class Add_Norm(nn.Module):
    def __init__(self, embedding_nums):
        super().__init__()
        self.add1 = nn.Linear(embedding_nums, embedding_nums)
        self.norm = nn.LayerNorm(embedding_nums)

    def forward(self, x):
        x = self.add1(x)
        x = self.norm(x)
        return x


class Feed_Forward(nn.Module):
    def __init__(self, embedding_nums, ff_nums):
        super().__init__()
        self.layer1 = nn.Linear(embedding_nums, ff_nums)
        self.gelu = nn.GELU()
        self.layer2 = nn.Linear(ff_nums, embedding_nums)

    def forward(self, x):
        x = self.layer1(x)
        x = self.gelu(x)
        x = self.layer2(x)

        return x


class Self_Attention(nn.Module):
    def __init__(self, embedding_nums, head_embedding_nums):
        super().__init__()
        self.head_embedding_nums = head_embedding_nums
        self.Q = nn.Linear(embedding_nums, head_embedding_nums)
        self.K = nn.Linear(embedding_nums, head_embedding_nums)
        self.V = nn.Linear(embedding_nums, head_embedding_nums)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, batch_seg_idx):
        q = self.Q(x)
        k = self.K(x)
        v = self.V(x)

        score = (q @ k.transpose(-1, -2)) / math.sqrt(self.head_embedding_nums)
        for i in range(x.shape[0]):
            seg_idx = batch_seg_idx[i]
            seg_idx = seg_idx.repeat(x.shape[1], 1)
            score[i][seg_idx==2] = -1e19

        score = self.softmax(score)
        res = score @ v
        return res


class Mult_Head(nn.Module):
    def __init__(self, config):
        super().__init__()
        assert config['embedding_nums'] % config['head_nums'] == 0, 'embedding维度不能整除多头数量'
        head_embedding_nums = int(config['embedding_nums'] / config['head_nums'])
        head_nums = config['head_nums']
        self.mult_head = [Self_Attention(config['embedding_nums'], head_embedding_nums).to(config['device']) for _ in range(head_nums)]
        self.W_O = nn.Linear(config['embedding_nums'], config['embedding_nums'])

    def forward(self, x, batch_seg_idx):
        mult_out = [self_att(x, batch_seg_idx) for self_att in self.mult_head]
        out = torch.cat(mult_out, dim=-1).to(x.device)
        out = self.W_O(out)

        return out


class Encoder_block(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.add_norm1 = Add_Norm(config['embedding_nums'])
        self.add_norm2 = Add_Norm(config['embedding_nums'])
        self.feed_forward = Feed_Forward(config['embedding_nums'], config['ff_nums'])
        self.mult_head_self_att = Mult_Head(config)
        self.dropout = nn.Dropout(0.1)

    def forward(self, x, batch_seg_idx):
        mult_head_x = self.mult_head_self_att(x, batch_seg_idx)
        an_x1 = self.add_norm1(mult_head_x)
        an_x1 = x + an_x1

        ff_x = self.feed_forward(x)
        an_x2 = self.add_norm2(ff_x)
        an_x2 = an_x1 + an_x2

        res = self.dropout(an_x2)
        return res


class Bert_Pool(nn.Module):
    def __init__(self, embedding_nums):
        super().__init__()
        self.linear = nn.Linear(embedding_nums, embedding_nums)
        self.tanh = nn.Tanh()

    def forward(self, x):
        x = x[:, 0]
        x = self.linear(x)
        x = self.tanh(x)
        return x

if __name__ == '__main__':
    data_path = os.path.join('data', 'all_data.csv')
    all_text1, all_text2, all_label = get_data(data_path)
    index2word = get_index2word(os.path.join('data', 'index2word.txt'))
    word2index = {word: i for i, word in enumerate(index2word)}

    config = {'embedding_nums': 768,
              'batch_size': 10,
              'epoch': 10,
              'lr':1e-3,
              'word2index': word2index,
              'index2word': index2word,
              'max_lens': 512,
              'text_type': 3,
              'head_nums': 4,
              'ff_nums': 768*4,
              'block_nums': 6,
              'device': 'cuda:0' if torch.cuda.is_available() else 'cpu'}

    train_dataset = BDataset(all_text1[720000:], all_text2[720000:], all_label[720000:], config)
    train_dataloader = DataLoader(train_dataset, batch_size=config['batch_size'], shuffle=True, collate_fn=train_dataset.process_batch)

    dev_dataset = BDataset(all_text1[-2000:], all_text2[-2000:], all_label[-2000:], config)
    dev_dataloader = DataLoader(train_dataset, batch_size=config['batch_size'], shuffle=False,
                                  collate_fn=dev_dataset.process_batch)

    model = Model(config).to(config['device'])
    opt = torch.optim.AdamW(model.parameters(), lr=config['lr'])
    for e in range(config['epoch']):
        e_loss = 0
        e_count = 0

        model.train()
        for batch_text_idx, batch_label, batch_seg_idx, batch_mask_idx in tqdm(train_dataloader):
            batch_text_idx = batch_text_idx.to(config['device'])
            batch_label= batch_label.to(config['device'])
            batch_seg_idx = batch_seg_idx.to(config['device'])
            batch_mask_idx = batch_mask_idx.to(config['device'])
            loss = model(batch_text_idx, batch_seg_idx, batch_label, batch_mask_idx)
            loss.backward()
            opt.step()
            opt.zero_grad()

            e_loss += loss
            e_count += 1

        avg_loss = e_loss / e_count


        acc_next_nums = 0
        next_nums = 0
        acc_mask_nums = 0
        mask_nums = 0
        model.eval()
        for batch_text_idx, batch_label, batch_seg_idx, batch_mask_idx in tqdm(dev_dataloader):
            batch_text_idx = batch_text_idx.to(config['device'])
            batch_label = batch_label.to(config['device'])
            batch_seg_idx = batch_seg_idx.to(config['device'])
            batch_mask_idx = batch_mask_idx.to(config['device'])
            pre_mask, pre_next = model(batch_text_idx, batch_seg_idx)

            acc_next_nums += sum(pre_next == batch_label)
            next_nums += len(batch_label)

            batch_nomask_idx = []
            for i in range(batch_mask_idx.shape[0]):
                no_mask_idx = []
                for j in range(batch_mask_idx.shape[1]):
                    if batch_mask_idx[i][j] != 0:
                        no_mask_idx.append(j)

                batch_nomask_idx.append(no_mask_idx)

            for i in range(len(batch_nomask_idx)):
                for j in batch_nomask_idx[i]:
                    if batch_mask_idx[i][j] == pre_mask[i][j]:
                        acc_mask_nums += 1
                    mask_nums += 1

        acc_next = acc_next_nums / next_nums
        acc_mask = acc_mask_nums / mask_nums
        print(f'第{e}个epoch: loss为{avg_loss:.4f}， 标签准确率为{acc_next:.4f}, mask准确率为{acc_mask:.4f}')




