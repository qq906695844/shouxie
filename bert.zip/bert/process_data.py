import os
import pandas as pd
import random
from tqdm import tqdm
import re

# def split_text(all_text):
#     res = []
#     stop_word = ['，', ',', '.', '。', '!', '！', '?', '？', ';', '；', ':', '：']
#     skip_word = [' ', '\t']
#     for text in tqdm(all_text):
#         if len(text) > 3:
#             text_tmp = ''
#             tmp_res = []
#             for word in text:
#                 random_rate = random.random()
#                 if word in skip_word:
#                     continue
#                 elif word in stop_word:
#                     if len(text_tmp) == 0:
#                         continue
#
#                     elif random_rate <= 0.2:
#                         text_tmp += word
#                         tmp_res.append(text_tmp)
#                         text_tmp = ''
#                     elif len(text) < 30 or random_rate >= 0.8:
#                         text_tmp += word
#
#                     else:
#                         text_tmp += word
#                         tmp_res.append(text_tmp)
#                         text_tmp = ''
#                 else:
#                     text_tmp += word
#             if text_tmp != '':
#                 tmp_res.append(text_tmp)
#             res.append(tmp_res)
#     return res

def split_text(text):
    text = re.sub(r'\s', '', text)
    res = []
    patten = r'[，：；。？?,:;]'
    try:
        sp_text = re.split(patten, text)
    except Exception as e:
        pass
    sentence = ''
    for per_text in sp_text:
        if per_text == '':
            continue

        if random.random() <= 0.2 and sentence == '':
            sentence += per_text
            sign_idx = text.index(per_text) + len(per_text)
            if sign_idx < len(text):
                sentence += text[sign_idx]
            res.append(sentence)
            sentence = ''
            continue

        if len(sentence) < 30 or random.random() <= 0.2:
            sentence += per_text

            sign_idx = text.index(per_text) + len(per_text)

            if sign_idx < len(text):
                sentence += text[sign_idx]

        else:
            sentence += per_text
            sign_idx = text.index(per_text) + len(per_text)

            if sign_idx < len(text):
                sentence += text[sign_idx]

            res.append(sentence)
            sentence = ''

    if sentence != '':
        res.append(sentence)

    return res


def process_text(all_text):
    text1 = []
    text2 = []
    label = []
    for text in tqdm(all_text):
        sp_text = split_text(text)
        per_text1, per_text2, per_label = build_table_text(sp_text)
        text1 += per_text1
        text2 += per_text2
        label += per_label

    res_df = pd.DataFrame({'text1': text1, 'text2': text2, 'label': label})
    res_df.to_csv('all_data.csv', index=False)


def build_table_text(text):
    text1 = []
    text2 = []
    label = []
    if len(text) >= 3:
        for i in range(0, len(text)-1):
            remove_list = [j for j in range(len(text)) if j not in [i, i+1]]
            text1.append(text[i])
            text1.append(text[i])
            text2.append(text[i+1])
            text2.append(text[random.choice(remove_list)])
            label.append(1)
            label.append(0)
    return text1, text2, label

def build_word2index(all_text):
    if os.path.exists(os.path.join('data', 'index2word.txt')):
        with open(os.path.join('data', 'index2word.txt'), 'r', encoding='utf-8-sig') as f:
            index2word = f.read().split('\n')
        word2index = {word: i for i, word in enumerate(index2word)}

    else:
        word2index = {'[PAD]': 0, '[CLS]': 1, '[SEP]': 2, '[MASK]': 3, '[UNK]': 4}
        for text in all_text:
            text = text = re.sub(r'\s', '', text)
            for word in text:
                if word not in word2index:
                    word2index[word] = len(word2index)

        index2word = list(word2index)
        with open(os.path.join('data', 'index2word.txt'), 'w', encoding='utf-8') as f:
            f.write('\n'.join(index2word))

    return word2index, index2word



if __name__ == '__main__':
    all_text = pd.read_csv(os.path.join('data', 'test_data.csv'))['content'].to_list()
    sp_list = process_text(all_text)
    word2index, index2word = build_word2index(all_text)
    pass